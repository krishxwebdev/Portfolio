import "./About.css";
import { motion } from "framer-motion";
import { fadeLeft, fadeRight } from "../../utils/animations";
import {
  FaLaptopCode,
  FaServer,
  FaDatabase,
  FaRocket,
} from "react-icons/fa";

function About() {
  const cards = [
    {
      icon: <FaLaptopCode />,
      title: "Frontend Development",
      desc: "Building responsive and modern user interfaces using React, JavaScript, HTML and CSS.",
    },
    {
      icon: <FaServer />,
      title: "Backend Development",
      desc: "Creating REST APIs with Node.js and Express while following clean architecture.",
    },
    {
      icon: <FaDatabase />,
      title: "Database",
      desc: "Designing scalable MySQL databases with efficient queries and relationships.",
    },
    {
      icon: <FaRocket />,
      title: "Continuous Learning",
      desc: "Currently learning Full Stack Development, Git, deployment and modern web technologies.",
    },
  ];

  return (
    <section className="about" id="about">
      <div className="about-container">
        <motion.div
            variants={fadeLeft}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.25 }}
>
          <span className="section-tag">
            ABOUT ME
          </span>

          <h2>
            Passionate About Building
            Modern Web Applications
          </h2>

          <p>
            I'm Krishna, an aspiring Full Stack Developer currently pursuing
            my Bachelor's degree while building practical web applications
            using modern technologies.
          </p>

          <p>
            My focus is on creating fast, responsive and scalable websites
            while continuously improving my frontend, backend and database
            development skills.
          </p>

          <div className="stats">

            <div className="stat-card">
              <h3>1+</h3>
              <span>Internship</span>
            </div>

            <div className="stat-card">
              <h3>10+</h3>
              <span>Projects</span>
            </div>

            <div className="stat-card">
              <h3>15+</h3>
              <span>Technologies</span>
            </div>

          </div>

        </motion.div>

        <motion.div
          className="about-right"
          initial={{ opacity: 0, x: 60 }}
          whileInView={{ opacity: 1, x: 0 }}
          transition={{ duration: .7 }}
          viewport={{ once: true }}
        >

          {cards.map((card, index) => (

            <div
              className="focus-card"
              key={index}
            >

              <div className="card-icon">
                {card.icon}
              </div>

              <h3>{card.title}</h3>

              <p>{card.desc}</p>

            </div>

          ))}

        </motion.div>

      </div>
    </section>
  );
}

export default About;