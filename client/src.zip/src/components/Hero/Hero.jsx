import "./Hero.css";
import { Typewriter } from "react-simple-typewriter";
import { FaGithub, FaLinkedin, FaEnvelope } from "react-icons/fa";
import portfolio from "../../data/portfolio";
import CodeCard from "./CodeCard";

function Hero() {
  return (
    <section className="hero" id="home">
      <div className="hero-container">

        <div className="hero-left">

          <p className="location">
            📍 {portfolio.location}
          </p>

          <h3>Hello, I'm</h3>

          <h1>{portfolio.name}</h1>

          <h2>
            <Typewriter
              words={portfolio.roles}
              loop={0}
              cursor
              cursorStyle="|"
            />
          </h2>

          <p className="description">
            {portfolio.description}
          </p>

          <div className="hero-buttons">

            <button className="gold-btn">
              Download Resume
            </button>

            <button className="outline-btn">
              View Projects
            </button>

            <button className="outline-btn">
              Contact
            </button>

          </div>

          <div className="socials">

            <FaGithub />

            <FaLinkedin />

            <FaEnvelope />

          </div>

        </div>

        <div className="hero-right">

          <CodeCard />

        </div>

      </div>
    </section>
  );
}

export default Hero;