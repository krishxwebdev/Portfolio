const portfolio = {
  name: "Krishna",
  title: "Aspiring Full Stack Developer",

  location: "Bengaluru, India",

  roles: [
    "Frontend Developer",
    "React Developer",
    "Full Stack Developer",
    "Node.js Developer",
  ],

  description:
    "I build responsive, modern web applications with React, Node.js, Express, and MySQL. I'm focused on writing clean code, solving real-world problems, and continuously improving my full-stack development skills.",

  social: {
    github: "",
    linkedin: "",
    email: "",
  },
};

export default portfolio;